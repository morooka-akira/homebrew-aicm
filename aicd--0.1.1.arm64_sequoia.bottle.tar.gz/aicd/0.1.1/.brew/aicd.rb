class Aicd < Formula
  desc "AI Code Development tool"
  homepage "https://github.com/morooka-akira/homebrew-aicm"
  
  if OS.mac?
    url "https://github.com/morooka-akira/homebrew-aicm/releases/download/v0.1.1/aicm-aarch64-apple-darwin"
    sha256 "305a102fffe28b89072034435cbe0c22db74a895bae44102fdd07c94fe38cf5c"
  elsif OS.linux?
    url "https://github.com/morooka-akira/homebrew-aicm/releases/download/v0.1.1/aicm-x86_64-unknown-linux-gnu"
    sha256 "594cceb248e02383952b56a1050bea5271eaf0ec1f472bfdda090ea995604644"
  end
  
  license "MIT"

  def install
    bin.install Dir["*"].first => "aicd"
  end

  test do
    system bin/"aicd", "--version"
  end
end
